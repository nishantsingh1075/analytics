package com.icicipru.main;

import com.icicipru.pojo.Account;

public class AccountMain {
	public static void main(String[] args) {
		Account account = new Account();
		account.setAccountNumber(101);
		account.setName("Nishant Singh");
		account.setBalance(1000);
		
		Account account2 = new Account();
		account2.setAccountNumber(102);
		account2.setName("Faizal Khan");
		account2.setBalance(1043);
		
		Account account3 = new Account(103,"Thanos", 10372);
		System.out.println("Balance for Account Number "+account.getAccountNumber()+" of "+account.getName()+" is "+account.getBalance());
		System.out.println("Balance for Account Number "+account2.getAccountNumber()+" of "+account2.getName()+" is "+account2.getBalance());
		System.out.println(account3);
		
	}
}
