package com.icicipru.main;

import java.util.Scanner;

import com.icicipru.pojo.Account;

public class AccountMainV2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		long accountnumber;
		String name;
		double balance;
		System.out.println("Enter Account Number, Name, Balance");
		accountnumber = scanner.nextLong();
		scanner.next();
		name = scanner.nextLine();
		balance = scanner.nextDouble();
		Account account = new Account(accountnumber, name, balance);
		System.out.println("Account Details");
		System.out.println(account);
		}
}