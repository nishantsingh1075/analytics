package com.icicipru.main;

import java.util.Scanner;

import com.icicipru.pojo.Account;

public class AccountMainV3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		long accountnumber;
		String name;
		double balance;
		
		System.out.println("Enter Account Number, Name, Balance");
		
		accountnumber = scanner.nextLong();
		scanner.next();
		name = scanner.nextLine();
		balance = scanner.nextDouble();
		
		Account account = new Account(accountnumber, name, balance);
		
		System.out.println("Account Details");
		System.out.println(account);
		String continueChoice = "Yes";
		double amount;
		do {
			System.out.println("Menu");
			System.out.println("1.. Withdraw");
			System.out.println("2..Deposit");
			System.out.println("3..Balance");
			int accountChoice = scanner.nextInt();
		switch(accountChoice) {
			case 1:
				System.out.println("enter amount to be withdrawn");
				amount = scanner.nextDouble();
				if (account.withdraw(amount))
				{
					System.out.println("Success");
					System.out.println("The balance is "+account.getBalance());
				}
				else {
					System.out.println("Failure");
					System.out.println("Balance is "+account.getBalance());
				}
				break;
			case 2:
				System.out.println("enter amount to deposit");
				amount = scanner.nextDouble();
				if (account.deposit(amount)) {
					System.out.println("Success");
					System.out.println("Balance is"+account.getBalance());
				}
				else {
					System.out.println("Failure");
					System.out.println("The Balance is "+account.getBalance());

				}
				break;
			case 3:
				System.out.println("The balance is "+account.getBalance());
				break;
			

		}
		System.out.println("Do you want to continue");
		continueChoice = scanner.next();
		}while(continueChoice.equals("Yes"));
		System.out.println("Thank you");
}
}
