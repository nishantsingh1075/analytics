package com.icicipru.main;

import java.util.Scanner;

import com.icicipru.pojo.Account;
import com.icicipru.pojo.Current;
import com.icicipru.pojo.Savings;

public class AccountMainv4 {

	public static void main(String[] args) {
		//Savings savings = new Savings();
		Scanner scanner = new Scanner(System.in);
		long accountnumber;
		String name;
		double balance;
		
		System.out.println("Enter Account Number, Name, Balance");
		
		accountnumber = scanner.nextLong();
		scanner.next();
		name = scanner.nextLine();
		balance = scanner.nextDouble();
		Current current = new Current(accountnumber,name,balance,50000);
		System.out.println("Account Details");
		System.out.println(current);
		String continueChoice = "Yes";
		double amount;
		do {
			System.out.println("Menu");
			System.out.println("1.. Withdraw");
			System.out.println("2..Deposit");
			System.out.println("3..Balance");
			int accountChoice = scanner.nextInt();
			
		switch(accountChoice) {
			case 1:
				System.out.println("enter amount to be withdrawn");
				amount = scanner.nextDouble();
				if (current.withdraw(amount))
				{
					System.out.println("Success");
					System.out.println("The balance is "+current.getBalance());
					System.out.println(" Overdraft is "+current.getOverdraft());
				}
				else {
					System.out.println("Failure");
					System.out.println("Balance is "+current.getBalance());
					System.out.println(" Overdraft is "+current.getOverdraft());
				}
				break;
			case 2:
				System.out.println("enter amount to deposit");
				amount = scanner.nextDouble();
				if (current.deposit(amount)) {
					System.out.println("Success");
					System.out.println("Balance is"+current.getBalance());
					System.out.println(" Overdraft is "+current.getOverdraft());
				}
				else {
					System.out.println("Failure");
					System.out.println("The Balance is "+current.getBalance());
					System.out.println(" Overdraft is "+current.getOverdraft());

				}
				break;
			case 3:
				System.out.println("The balance is "+current.getBalance());
				System.out.println(" Overdraft is "+current.getOverdraft());
				break;
			

		}
		System.out.println("Do you want to continue");
		continueChoice = scanner.next();
		}while(continueChoice.equals("Yes"));
		System.out.println("Thank you");
	}

}
