package com.icicipru.pojo;

public class Current extends Account{
	private double overdraftLimit;
	private double overdraft;
	public Current() {
		
	}
	public Current(long accountnumber, String name, double balance, double overdraftLimit) {
		super(accountnumber, name, balance);
		this.overdraftLimit = overdraftLimit;
		this.overdraft = overdraftLimit;
	}
	
	public double getOverdraft() {
		return overdraft;
	}
	public void setOverdraft(double overdraft) {
		this.overdraft = overdraft;
	}
	public double getOverdraftLimit() {
		return overdraftLimit;
	}
	public void setOverdraftLimit(double overdraftLimit) {
		this.overdraftLimit = overdraftLimit;
	}
	
	public boolean deposit(double amount) {
		if(amount>(overdraft-overdraftLimit)) {
			double overdraft1 = overdraft;
			setOverdraft(overdraftLimit);
			return super.deposit(amount-(overdraftLimit-overdraft1));
		}
		else
			return super.deposit(amount);
			
	}
	
	public boolean withdraw(double amount) {
		if (getBalance()<amount && overdraft >= amount-getBalance()) {
			setOverdraft(getOverdraft()-(amount - getBalance()));
			return super.withdraw(getBalance());
		}
		else return super.withdraw(amount);
		
	}
	public String toString() {
		return "Current [overdraft=" + overdraft + ", getAccountNumber()=" + getAccountNumber() + ", getName()="
				+ getName() + ", getBalance()=" + getBalance() + "]";
	}
	
}
