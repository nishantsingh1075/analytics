package com.icicipru.pojo;

public class Savings extends Account {
	private boolean isSalary;
	public Savings()
	{
		System.out.println("in default constructor of savings");
	}
	public Savings(long accountNumber, String name, double balance, boolean isSalary)
	{
		super(accountNumber,name,balance);
		this.isSalary = isSalary;
		System.out.println("in Parametrized constructor of savings");
	}
	public boolean isSalary() {
		return isSalary;
	}
	public void setSalary(boolean isSalary) {
		this.isSalary = isSalary;
	}
	
	public boolean withdraw(double amount) {
		if(isSalary&&amount<=getBalance())
		{
			super.withdraw(amount);
		}
		else if (super.getBalance()-amount == 1500)
			return super.withdraw(amount);
		return false;
	}
	
	public boolean deposit(double amount) {
		return super.deposit(amount);
	}
	public String toString() {
		return "Savings [Salary=" + isSalary + " Account Number=" + getAccountNumber() + " Name="
				+ getName() + " Balance=" + getBalance() + "]";
	}
	
}


